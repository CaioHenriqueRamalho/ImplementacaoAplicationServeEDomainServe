﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DDD.Domain.PicContext
{
    public class PosGraduacao
    {
        public int posGraduacaoId { get; set; }
        public int pesquisadorID { get; set; }
        public int ProjetoId { get; set; }

    }
}